﻿namespace GuitarsProject
{
    public class GuitarString
    {
        public string Gauge { get; set; } // толщина струн (Extra Light, Light, Medium)
        public string Metal { get; set; } //никель, сталь
    }
}