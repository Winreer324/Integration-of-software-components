﻿namespace GuitarsProject
{
    public class Neck
    {
        public string Wood { get; set; } //материал изготовления (красное дерево, клён, липа и т.д.)
        public int FretsCount { get; set; } //количество ладов (22, 24)
    }
}