﻿namespace GuitarsProject
{
    public class Body
    {
        public string Wood { get; set; } //материал изготовления (красное дерево, клён, липа и т.д.)
        public bool Cover { get; set; } //накладка (естьили нет)
    }
}